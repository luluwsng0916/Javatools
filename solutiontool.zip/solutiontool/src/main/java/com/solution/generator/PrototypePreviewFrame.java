package com.solution.generator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class PrototypePreviewFrame extends JFrame {

    private List<PrototypeGenerator.PagePrototype> pages;
    private JPanel contentPanel;
    private JLabel pageTitleLabel;
    private JButton[] pageButtons;
    private int currentPageIndex = 0;

    private static final Color PRIMARY_COLOR = new Color(66, 139, 202);
    private static final Color SECONDARY_COLOR = new Color(240, 240, 240);
    private static final Color BORDER_COLOR = new Color(200, 200, 200);
    private static final Color TEXT_COLOR = new Color(51, 51, 51);
    private static final Color LIGHT_TEXT = new Color(102, 102, 102);

    public PrototypePreviewFrame(List<PrototypeGenerator.PagePrototype> pages) {
        this.pages = pages;
        initUI();
    }

    private void initUI() {
        setTitle("原型图预览");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel bodyPanel = new JPanel(new BorderLayout(15, 0));

        JPanel navPanel = createNavigationPanel();
        bodyPanel.add(navPanel, BorderLayout.WEST);

        JPanel previewPanel = createPreviewPanel();
        bodyPanel.add(previewPanel, BorderLayout.CENTER);

        mainPanel.add(bodyPanel, BorderLayout.CENTER);

        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);

        if (!pages.isEmpty()) {
            showPage(0);
        }
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PRIMARY_COLOR);
        panel.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel titleLabel = new JLabel("原型图设计预览", JLabel.LEFT);
        titleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel, BorderLayout.WEST);

        JLabel infoLabel = new JLabel("共 " + pages.size() + " 个页面原型", JLabel.RIGHT);
        infoLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        infoLabel.setForeground(Color.WHITE);
        panel.add(infoLabel, BorderLayout.EAST);

        return panel;
    }

    private JPanel createNavigationPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(200, 0));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                " 页面导航 ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Microsoft YaHei", Font.BOLD, 14),
                PRIMARY_COLOR
        ));

        JPanel listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        pageButtons = new JButton[pages.size()];

        for (int i = 0; i < pages.size(); i++) {
            final int index = i;
            PrototypeGenerator.PagePrototype page = pages.get(i);

            JButton btn = new JButton((i + 1) + ". " + page.getPageName());
            btn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
            btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            btn.setHorizontalAlignment(SwingConstants.LEFT);
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setBackground(SECONDARY_COLOR);
            btn.setForeground(TEXT_COLOR);
            btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));

            final int btnIndex = i;
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    showPage(btnIndex);
                }
            });

            pageButtons[i] = btn;
            listPanel.add(btn);
            listPanel.add(Box.createVerticalStrut(5));
        }

        listPanel.add(Box.createVerticalGlue());

        JScrollPane scrollPane = new JScrollPane(listPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);

        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createPreviewPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                " 页面预览 ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Microsoft YaHei", Font.BOLD, 14),
                PRIMARY_COLOR
        ));

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        titlePanel.setBackground(new Color(248, 248, 248));

        pageTitleLabel = new JLabel("", JLabel.CENTER);
        pageTitleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
        pageTitleLabel.setForeground(PRIMARY_COLOR);
        titlePanel.add(pageTitleLabel, BorderLayout.CENTER);

        panel.add(titlePanel, BorderLayout.NORTH);

        contentPanel = new JPanel();
        contentPanel.setBorder(new EmptyBorder(20, 30, 20, 30));
        contentPanel.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(null);

        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton prevBtn = new JButton("← 上一页");
        prevBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        prevBtn.setPreferredSize(new Dimension(120, 40));
        prevBtn.setBackground(SECONDARY_COLOR);
        prevBtn.setForeground(TEXT_COLOR);
        prevBtn.setFocusPainted(false);
        prevBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        prevBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentPageIndex > 0) {
                    showPage(currentPageIndex - 1);
                }
            }
        });

        JButton nextBtn = new JButton("下一页 →");
        nextBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        nextBtn.setPreferredSize(new Dimension(120, 40));
        nextBtn.setBackground(SECONDARY_COLOR);
        nextBtn.setForeground(TEXT_COLOR);
        nextBtn.setFocusPainted(false);
        nextBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        nextBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentPageIndex < pages.size() - 1) {
                    showPage(currentPageIndex + 1);
                }
            }
        });

        JButton closeBtn = new JButton("关闭预览");
        closeBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        closeBtn.setPreferredSize(new Dimension(120, 40));
        closeBtn.setBackground(new Color(243, 156, 18));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFocusPainted(false);
        closeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeBtn.setOpaque(true);
        closeBtn.setBorderPainted(false);
        closeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        panel.add(prevBtn);
        panel.add(nextBtn);
        panel.add(closeBtn);

        return panel;
    }

    private void showPage(int index) {
        if (index < 0 || index >= pages.size()) {
            return;
        }

        currentPageIndex = index;
        PrototypeGenerator.PagePrototype page = pages.get(index);

        pageTitleLabel.setText(page.getPageName() + " - " + page.getDescription());

        for (int i = 0; i < pageButtons.length; i++) {
            if (i == index) {
                pageButtons[i].setBackground(PRIMARY_COLOR);
                pageButtons[i].setForeground(Color.WHITE);
            } else {
                pageButtons[i].setBackground(SECONDARY_COLOR);
                pageButtons[i].setForeground(TEXT_COLOR);
            }
        }

        renderPageContent(page);
    }

    private void renderPageContent(PrototypeGenerator.PagePrototype page) {
        contentPanel.removeAll();

        String layoutType = page.getLayoutType();

        if ("grid".equals(layoutType) || page.getComponents().size() <= 10) {
            renderGridLayout(page);
        } else {
            renderBorderLayout(page);
        }

        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void renderGridLayout(PrototypeGenerator.PagePrototype page) {
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;
        int col = 0;
        int maxCols = 2;

        for (PrototypeGenerator.ComponentInfo comp : page.getComponents()) {
            JComponent component = createComponent(comp);

            if (component != null) {
                gbc.gridx = col;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;

                if ("label".equals(comp.getType())) {
                    gbc.gridwidth = maxCols;
                    gbc.anchor = GridBagConstraints.CENTER;
                    col = 0;
                    row++;
                } else if ("button".equals(comp.getType()) || "link".equals(comp.getType())) {
                    gbc.anchor = GridBagConstraints.CENTER;
                    col++;
                    if (col >= maxCols) {
                        col = 0;
                        row++;
                    }
                } else {
                    gbc.fill = GridBagConstraints.HORIZONTAL;
                    gbc.weightx = 0.5;
                    col++;
                    if (col >= maxCols) {
                        col = 0;
                        row++;
                    }
                }

                formPanel.add(component, gbc);
            }
        }

        contentPanel.setLayout(new BorderLayout());
        contentPanel.add(formPanel, BorderLayout.NORTH);
    }

    private void renderBorderLayout(PrototypeGenerator.PagePrototype page) {
        JPanel wrapperPanel = new JPanel(new BorderLayout(15, 15));
        wrapperPanel.setBackground(Color.WHITE);

        JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        northPanel.setBackground(Color.WHITE);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(Color.WHITE);

        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        southPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        int centerRow = 0;

        for (PrototypeGenerator.ComponentInfo comp : page.getComponents()) {
            JComponent component = createComponent(comp);

            if (component != null) {
                String pos = comp.getPosition();

                if ("north".equals(pos) || "label".equals(comp.getType())) {
                    northPanel.add(component);
                } else if ("south".equals(pos) || "button".equals(comp.getType())) {
                    southPanel.add(component);
                } else {
                    gbc.gridx = 0;
                    gbc.gridy = centerRow++;
                    gbc.fill = GridBagConstraints.HORIZONTAL;
                    gbc.weightx = 1.0;
                    centerPanel.add(component, gbc);
                }
            }
        }

        wrapperPanel.add(northPanel, BorderLayout.NORTH);

        JPanel centerWrapper = new JPanel(new BorderLayout());
        centerWrapper.setBackground(Color.WHITE);
        centerWrapper.add(centerPanel, BorderLayout.NORTH);
        wrapperPanel.add(centerWrapper, BorderLayout.CENTER);

        wrapperPanel.add(southPanel, BorderLayout.SOUTH);

        contentPanel.setLayout(new BorderLayout());
        contentPanel.add(wrapperPanel, BorderLayout.NORTH);
    }

    private JComponent createComponent(PrototypeGenerator.ComponentInfo comp) {
        String type = comp.getType();
        String label = comp.getLabel();

        switch (type) {
            case "label":
                return createLabelComponent(comp);
            case "text":
                return createTextFieldComponent(comp);
            case "password":
                return createPasswordFieldComponent(comp);
            case "textarea":
                return createTextAreaComponent(comp);
            case "button":
                return createButtonComponent(comp);
            case "checkbox":
                return createCheckBoxComponent(comp);
            case "radio":
                return createRadioButtonComponent(comp);
            case "select":
                return createComboBoxComponent(comp);
            case "link":
                return createLinkComponent(comp);
            case "card":
                return createCardComponent(comp);
            case "chart":
                return createChartComponent(comp);
            case "table":
                return createTableComponent(comp);
            case "pagination":
                return createPaginationComponent(comp);
            case "image":
                return createImageComponent(comp);
            default:
                return createGenericComponent(comp);
        }
    }

    private JLabel createLabelComponent(PrototypeGenerator.ComponentInfo comp) {
        JLabel label = new JLabel(comp.getLabel(), JLabel.CENTER);
        label.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
        label.setForeground(PRIMARY_COLOR);
        label.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return label;
    }

    private JPanel createTextFieldComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setBackground(Color.WHITE);

        JLabel label = new JLabel(comp.getLabel() + (comp.isRequired() ? " *" : ""));
        label.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        label.setPreferredSize(new Dimension(100, 35));

        JTextField textField = new JTextField();
        textField.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        textField.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        textField.setToolTipText("请输入" + comp.getLabel());

        panel.add(label, BorderLayout.WEST);
        panel.add(textField, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createPasswordFieldComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setBackground(Color.WHITE);

        JLabel label = new JLabel(comp.getLabel() + (comp.isRequired() ? " *" : ""));
        label.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        label.setPreferredSize(new Dimension(100, 35));

        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        passwordField.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        panel.add(label, BorderLayout.WEST);
        panel.add(passwordField, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createTextAreaComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setBackground(Color.WHITE);

        JLabel label = new JLabel(comp.getLabel() + (comp.isRequired() ? " *" : ""));
        label.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        label.setPreferredSize(new Dimension(100, 35));

        JTextArea textArea = new JTextArea();
        textArea.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setRows(4);
        textArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));

        panel.add(label, BorderLayout.WEST);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JButton createButtonComponent(PrototypeGenerator.ComponentInfo comp) {
        JButton button = new JButton(comp.getLabel());
        button.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private JCheckBox createCheckBoxComponent(PrototypeGenerator.ComponentInfo comp) {
        JCheckBox checkBox = new JCheckBox(comp.getLabel());
        checkBox.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        checkBox.setForeground(TEXT_COLOR);
        checkBox.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        checkBox.setBackground(Color.WHITE);
        return checkBox;
    }

    private JRadioButton createRadioButtonComponent(PrototypeGenerator.ComponentInfo comp) {
        JRadioButton radioButton = new JRadioButton(comp.getLabel());
        radioButton.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        radioButton.setForeground(TEXT_COLOR);
        radioButton.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        radioButton.setBackground(Color.WHITE);
        return radioButton;
    }

    private JPanel createComboBoxComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setBackground(Color.WHITE);

        JLabel label = new JLabel(comp.getLabel());
        label.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        label.setPreferredSize(new Dimension(100, 35));

        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        comboBox.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));

        if (comp.getOptions() != null && !comp.getOptions().isEmpty()) {
            for (String option : comp.getOptions()) {
                comboBox.addItem(option);
            }
        } else {
            comboBox.addItem("请选择");
        }

        panel.add(label, BorderLayout.WEST);
        panel.add(comboBox, BorderLayout.CENTER);

        return panel;
    }

    private JLabel createLinkComponent(PrototypeGenerator.ComponentInfo comp) {
        JLabel link = new JLabel("<html><u>" + comp.getLabel() + "</u></html>");
        link.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        link.setForeground(PRIMARY_COLOR);
        link.setCursor(new Cursor(Cursor.HAND_CURSOR));
        link.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        return link;
    }

    private JPanel createCardComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel card = new JPanel(new BorderLayout());
        card.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        card.setBackground(new Color(248, 248, 248));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel titleLabel = new JLabel(comp.getLabel(), JLabel.CENTER);
        titleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        titleLabel.setForeground(TEXT_COLOR);

        JLabel valueLabel = new JLabel("--", JLabel.CENTER);
        valueLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
        valueLabel.setForeground(PRIMARY_COLOR);

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    private JPanel createChartComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel chart = new JPanel(new BorderLayout());
        chart.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        chart.setBackground(new Color(252, 252, 252));
        chart.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JLabel titleLabel = new JLabel("【" + comp.getLabel() + "】 - 图表预览区域", JLabel.CENTER);
        titleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        titleLabel.setForeground(LIGHT_TEXT);

        JLabel hintLabel = new JLabel("(实际项目中可使用 ECharts/Highcharts 等图表库)", JLabel.CENTER);
        hintLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        hintLabel.setForeground(Color.GRAY);

        chart.add(titleLabel, BorderLayout.CENTER);
        chart.add(hintLabel, BorderLayout.SOUTH);

        return chart;
    }

    private JPanel createTableComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        tablePanel.setBackground(Color.WHITE);

        String[] columns = {"ID", "名称", "状态", "创建时间", "操作"};
        Object[][] data = {
                {"1", "示例数据1", "正常", "2024-01-15 10:30", "编辑 | 删除"},
                {"2", "示例数据2", "正常", "2024-01-15 11:20", "编辑 | 删除"},
                {"3", "示例数据3", "禁用", "2024-01-14 09:15", "编辑 | 删除"},
                {"4", "示例数据4", "正常", "2024-01-14 14:45", "编辑 | 删除"},
                {"5", "示例数据5", "正常", "2024-01-13 16:20", "编辑 | 删除"}
        };

        JTable table = new JTable(data, columns);
        table.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Microsoft YaHei", Font.BOLD, 13));
        table.getTableHeader().setBackground(SECONDARY_COLOR);
        table.setSelectionBackground(PRIMARY_COLOR);
        table.setSelectionForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                " " + comp.getLabel() + " ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Microsoft YaHei", Font.BOLD, 14),
                PRIMARY_COLOR
        ));

        tablePanel.add(scrollPane, BorderLayout.CENTER);

        return tablePanel;
    }

    private JPanel createPaginationComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panel.setBackground(Color.WHITE);

        JLabel infoLabel = new JLabel("共 100 条记录，第 1 / 10 页");
        infoLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        infoLabel.setForeground(LIGHT_TEXT);

        JButton prevBtn = new JButton("上一页");
        prevBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        prevBtn.setEnabled(false);

        JButton page1 = new JButton("1");
        page1.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        page1.setBackground(PRIMARY_COLOR);
        page1.setForeground(Color.WHITE);
        page1.setOpaque(true);
        page1.setBorderPainted(false);

        JButton page2 = new JButton("2");
        page2.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));

        JButton page3 = new JButton("3");
        page3.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));

        JLabel dots = new JLabel("...");
        dots.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));

        JButton page10 = new JButton("10");
        page10.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));

        JButton nextBtn = new JButton("下一页");
        nextBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));

        panel.add(infoLabel);
        panel.add(prevBtn);
        panel.add(page1);
        panel.add(page2);
        panel.add(page3);
        panel.add(dots);
        panel.add(page10);
        panel.add(nextBtn);

        return panel;
    }

    private JPanel createImageComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel imagePanel = new JPanel(new BorderLayout());
        imagePanel.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        imagePanel.setBackground(new Color(240, 240, 240));
        imagePanel.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        JLabel placeholder = new JLabel("[ " + comp.getLabel() + " ]", JLabel.CENTER);
        placeholder.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        placeholder.setForeground(LIGHT_TEXT);

        imagePanel.add(placeholder, BorderLayout.CENTER);

        return imagePanel;
    }

    private JPanel createGenericComponent(PrototypeGenerator.ComponentInfo comp) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(comp.getWidth(), comp.getHeight()));
        panel.setBackground(new Color(250, 250, 250));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                " " + comp.getLabel() + " ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Microsoft YaHei", Font.PLAIN, 12),
                LIGHT_TEXT
        ));

        return panel;
    }
}
