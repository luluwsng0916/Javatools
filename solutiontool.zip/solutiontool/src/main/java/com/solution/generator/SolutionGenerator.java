package com.solution.generator;

import java.util.ArrayList;
import java.util.List;

public class SolutionGenerator {

    public String generateSolution(String requirement) {
        if (requirement == null || requirement.trim().isEmpty()) {
            return "请输入有效的软件需求内容。";
        }

        StringBuilder solution = new StringBuilder();
        solution.append("========================================\n");
        solution.append("           解决方案生成报告\n");
        solution.append("========================================\n\n");
        solution.append("【原始需求】\n");
        solution.append(requirement);
        solution.append("\n\n");
        solution.append("========================================\n\n");
        
        List<String> keywords = extractKeywords(requirement.toLowerCase());
        
        solution.append("【架构设计建议】\n");
        solution.append(generateArchitecture(requirement, keywords));
        solution.append("\n\n");
        
        solution.append("【技术栈推荐】\n");
        solution.append(generateTechStack(keywords));
        solution.append("\n\n");
        
        solution.append("【核心模块设计】\n");
        solution.append(generateModules(requirement, keywords));
        solution.append("\n\n");
        
        solution.append("【数据库设计】\n");
        solution.append(generateDatabase(requirement, keywords));
        solution.append("\n\n");
        
        solution.append("【接口设计】\n");
        solution.append(generateAPIs(requirement, keywords));
        solution.append("\n\n");
        
        solution.append("【安全建议】\n");
        solution.append(generateSecurity(requirement, keywords));
        solution.append("\n\n");
        
        solution.append("【性能优化建议】\n");
        solution.append(generatePerformance(requirement, keywords));
        solution.append("\n\n");
        
        solution.append("========================================\n");
        solution.append("           报告生成完毕\n");
        solution.append("========================================\n");
        
        return solution.toString();
    }

    private List<String> extractKeywords(String requirement) {
        List<String> keywords = new ArrayList<>();
        
        if (requirement.contains("用户") || requirement.contains("登录") || requirement.contains("注册")) {
            keywords.add("user");
        }
        if (requirement.contains("数据") || requirement.contains("数据库")) {
            keywords.add("database");
        }
        if (requirement.contains("支付") || requirement.contains("订单")) {
            keywords.add("payment");
        }
        if (requirement.contains("管理") || requirement.contains("后台")) {
            keywords.add("admin");
        }
        if (requirement.contains("消息") || requirement.contains("通知")) {
            keywords.add("message");
        }
        if (requirement.contains("文件") || requirement.contains("上传") || requirement.contains("下载")) {
            keywords.add("file");
        }
        if (requirement.contains("报表") || requirement.contains("统计") || requirement.contains("分析")) {
            keywords.add("report");
        }
        if (requirement.contains("权限") || requirement.contains("角色")) {
            keywords.add("permission");
        }
        if (requirement.contains("搜索") || requirement.contains("查询")) {
            keywords.add("search");
        }
        if (requirement.contains("移动端") || requirement.contains("app") || requirement.contains("手机")) {
            keywords.add("mobile");
        }
        if (requirement.contains("web") || requirement.contains("网页") || requirement.contains("网站")) {
            keywords.add("web");
        }
        if (requirement.contains("api") || requirement.contains("接口")) {
            keywords.add("api");
        }
        if (requirement.contains("安全") || requirement.contains("加密")) {
            keywords.add("security");
        }
        
        return keywords;
    }

    private String generateArchitecture(String requirement, List<String> keywords) {
        StringBuilder arch = new StringBuilder();
        arch.append("推荐采用分层架构设计：\n");
        arch.append("  ┌─────────────────────────────────────┐\n");
        arch.append("  │           表现层 (Presentation)      │\n");
        arch.append("  │  (Controller/API Gateway/UI)        │\n");
        arch.append("  └─────────────────────────────────────┘\n");
        arch.append("                    ↓\n");
        arch.append("  ┌─────────────────────────────────────┐\n");
        arch.append("  │           业务层 (Business)          │\n");
        arch.append("  │  (Service/Domain Logic)             │\n");
        arch.append("  └─────────────────────────────────────┘\n");
        arch.append("                    ↓\n");
        arch.append("  ┌─────────────────────────────────────┐\n");
        arch.append("  │           持久层 (Persistence)       │\n");
        arch.append("  │  (DAO/Repository/Mapper)            │\n");
        arch.append("  └─────────────────────────────────────┘\n");
        arch.append("                    ↓\n");
        arch.append("  ┌─────────────────────────────────────┐\n");
        arch.append("  │           数据层 (Data)              │\n");
        arch.append("  │  (MySQL/Redis/Elasticsearch)        │\n");
        arch.append("  └─────────────────────────────────────┘\n\n");
        
        if (keywords.contains("mobile")) {
            arch.append("● 移动端适配建议：\n");
            arch.append("  - 采用前后端分离架构\n");
            arch.append("  - 提供RESTful API供移动端调用\n");
            arch.append("  - 考虑使用微服务架构拆分核心业务\n");
        }
        
        if (keywords.contains("api")) {
            arch.append("● API设计建议：\n");
            arch.append("  - 统一API路径前缀：/api/v1/\n");
            arch.append("  - 使用API Gateway进行统一管理\n");
            arch.append("  - 集成Swagger/OpenAPI文档\n");
        }
        
        return arch.toString();
    }

    private String generateTechStack(List<String> keywords) {
        StringBuilder stack = new StringBuilder();
        
        stack.append("【后端技术栈】\n");
        stack.append("  - 框架：Spring Boot 3.x\n");
        stack.append("  - 构建工具：Maven / Gradle\n");
        stack.append("  - JDK版本：Java 17+ (长期支持版)\n");
        stack.append("  - ORM框架：MyBatis-Plus / Spring Data JPA\n");
        stack.append("  - 数据库连接池：HikariCP / Druid\n\n");
        
        stack.append("【前端技术栈】\n");
        if (keywords.contains("mobile")) {
            stack.append("  - 移动端：Flutter / React Native / Uni-app\n");
        }
        stack.append("  - Web端：Vue 3.x + Element Plus / React + Ant Design\n");
        stack.append("  - 状态管理：Pinia / Redux\n");
        stack.append("  - HTTP客户端：Axios\n");
        stack.append("  - 构建工具：Vite\n\n");
        
        stack.append("【数据库】\n");
        stack.append("  - 关系型数据库：MySQL 8.0\n");
        stack.append("  - 缓存数据库：Redis 7.x\n");
        if (keywords.contains("search")) {
            stack.append("  - 搜索引擎：Elasticsearch\n");
        }
        if (keywords.contains("message")) {
            stack.append("  - 消息队列：RabbitMQ / Kafka\n");
        }
        stack.append("\n");
        
        stack.append("【中间件】\n");
        stack.append("  - API网关：Spring Cloud Gateway\n");
        stack.append("  - 服务注册发现：Nacos / Eureka\n");
        stack.append("  - 配置中心：Nacos Config / Apollo\n");
        stack.append("  - 分布式事务：Seata\n");
        stack.append("  - 分布式锁：Redisson\n\n");
        
        stack.append("【开发工具】\n");
        stack.append("  - IDE：IntelliJ IDEA\n");
        stack.append("  - 版本控制：Git\n");
        stack.append("  - 接口测试：Postman / Apifox\n");
        stack.append("  - 数据库工具：Navicat / DBeaver\n");
        
        return stack.toString();
    }

    private String generateModules(String requirement, List<String> keywords) {
        StringBuilder modules = new StringBuilder();
        int moduleCount = 1;
        
        if (keywords.contains("user")) {
            modules.append(moduleCount++).append(". 用户模块\n");
            modules.append("   ├── 用户注册与登录\n");
            modules.append("   ├── 用户信息管理\n");
            modules.append("   ├── 密码找回与重置\n");
            modules.append("   └── 用户状态管理\n\n");
        }
        
        if (keywords.contains("permission")) {
            modules.append(moduleCount++).append(". 权限管理模块\n");
            modules.append("   ├── 角色管理\n");
            modules.append("   ├── 菜单管理\n");
            modules.append("   ├── 权限分配\n");
            modules.append("   └── 数据权限控制\n\n");
        }
        
        if (keywords.contains("admin")) {
            modules.append(moduleCount++).append(". 后台管理模块\n");
            modules.append("   ├── 数据统计仪表盘\n");
            modules.append("   ├── 内容管理\n");
            modules.append("   ├── 系统配置\n");
            modules.append("   └── 操作日志\n\n");
        }
        
        if (keywords.contains("payment")) {
            modules.append(moduleCount++).append(". 订单支付模块\n");
            modules.append("   ├── 订单创建与管理\n");
            modules.append("   ├── 支付接口集成\n");
            modules.append("   ├── 订单状态流转\n");
            modules.append("   └── 退款处理\n\n");
        }
        
        if (keywords.contains("file")) {
            modules.append(moduleCount++).append(". 文件管理模块\n");
            modules.append("   ├── 文件上传与下载\n");
            modules.append("   ├── 文件类型校验\n");
            modules.append("   ├── 文件存储（本地/OSS）\n");
            modules.append("   └── 文件预览\n\n");
        }
        
        if (keywords.contains("message")) {
            modules.append(moduleCount++).append(". 消息通知模块\n");
            modules.append("   ├── 站内消息\n");
            modules.append("   ├── 短信通知\n");
            modules.append("   ├── 邮件通知\n");
            modules.append("   └── 消息推送\n\n");
        }
        
        if (keywords.contains("report")) {
            modules.append(moduleCount++).append(". 报表统计模块\n");
            modules.append("   ├── 数据统计\n");
            modules.append("   ├── 报表导出（Excel/PDF）\n");
            modules.append("   ├── 图表展示\n");
            modules.append("   └── 定时报表生成\n\n");
        }
        
        if (keywords.contains("search")) {
            modules.append(moduleCount++).append(". 搜索模块\n");
            modules.append("   ├── 全文检索\n");
            modules.append("   ├── 高级筛选\n");
            modules.append("   ├── 搜索热词统计\n");
            modules.append("   └── 搜索建议\n\n");
        }
        
        modules.append(moduleCount++).append(". 公共模块\n");
        modules.append("   ├── 统一返回结果\n");
        modules.append("   ├── 全局异常处理\n");
        modules.append("   ├── 参数校验\n");
        modules.append("   └── 工具类\n");
        
        return modules.toString();
    }

    private String generateDatabase(String requirement, List<String> keywords) {
        StringBuilder db = new StringBuilder();
        
        db.append("【核心数据表设计】\n\n");
        
        if (keywords.contains("user")) {
            db.append("1. 用户表 (sys_user)\n");
            db.append("   ├── id (主键)\n");
            db.append("   ├── username (用户名)\n");
            db.append("   ├── password (密码-加密存储)\n");
            db.append("   ├── nickname (昵称)\n");
            db.append("   ├── phone (手机号)\n");
            db.append("   ├── email (邮箱)\n");
            db.append("   ├── avatar (头像URL)\n");
            db.append("   ├── status (状态)\n");
            db.append("   ├── create_time (创建时间)\n");
            db.append("   └── update_time (更新时间)\n\n");
        }
        
        if (keywords.contains("permission")) {
            db.append("2. 角色表 (sys_role)\n");
            db.append("   ├── id, name, code, description, status\n\n");
            db.append("3. 菜单表 (sys_menu)\n");
            db.append("   ├── id, parent_id, name, path, component, perms, type\n\n");
            db.append("4. 用户角色关联表 (sys_user_role)\n");
            db.append("5. 角色菜单关联表 (sys_role_menu)\n\n");
        }
        
        if (keywords.contains("payment")) {
            db.append("6. 订单表 (biz_order)\n");
            db.append("   ├── id, order_no, user_id, total_amount, status\n");
            db.append("   ├── pay_time, create_time, update_time\n\n");
            db.append("7. 订单明细表 (biz_order_item)\n");
            db.append("   ├── id, order_id, product_id, quantity, price\n\n");
            db.append("8. 支付记录表 (biz_payment)\n");
            db.append("   ├── id, order_id, pay_no, pay_type, amount, status\n\n");
        }
        
        if (keywords.contains("file")) {
            db.append("9. 文件表 (sys_file)\n");
            db.append("   ├── id, file_name, file_type, file_size, file_url\n");
            db.append("   ├── storage_type, create_time\n\n");
        }
        
        if (keywords.contains("message")) {
            db.append("10. 消息表 (sys_message)\n");
            db.append("    ├── id, title, content, type, sender_id, receiver_id\n");
            db.append("    ├── is_read, read_time, create_time\n\n");
        }
        
        db.append("【数据库设计原则】\n");
        db.append("  - 遵循第三范式（3NF）减少数据冗余\n");
        db.append("  - 所有表包含主键、创建时间、更新时间字段\n");
        db.append("  - 逻辑删除使用 delete_flag 字段\n");
        db.append("  - 敏感数据加密存储\n");
        db.append("  - 合理建立索引优化查询性能\n");
        
        return db.toString();
    }

    private String generateAPIs(String requirement, List<String> keywords) {
        StringBuilder apis = new StringBuilder();
        int apiCount = 1;
        
        apis.append("【RESTful API 接口设计】\n\n");
        
        if (keywords.contains("user")) {
            apis.append("◆ 用户相关接口\n");
            apis.append(String.format("   %d. 用户注册", apiCount++)).append("\n");
            apis.append("      POST /api/v1/auth/register\n");
            apis.append("      参数: username, password, phone, email\n\n");
            apis.append(String.format("   %d. 用户登录", apiCount++)).append("\n");
            apis.append("      POST /api/v1/auth/login\n");
            apis.append("      参数: username, password\n");
            apis.append("      返回: token, userInfo\n\n");
            apis.append(String.format("   %d. 获取用户信息", apiCount++)).append("\n");
            apis.append("      GET /api/v1/users/info\n");
            apis.append("      Header: Authorization: Bearer {token}\n\n");
            apis.append(String.format("   %d. 更新用户信息", apiCount++)).append("\n");
            apis.append("      PUT /api/v1/users/info\n\n");
            apis.append(String.format("   %d. 修改密码", apiCount++)).append("\n");
            apis.append("      PUT /api/v1/users/password\n\n");
        }
        
        if (keywords.contains("payment")) {
            apis.append("◆ 订单相关接口\n");
            apis.append(String.format("   %d. 创建订单", apiCount++)).append("\n");
            apis.append("      POST /api/v1/orders\n\n");
            apis.append(String.format("   %d. 查询订单列表", apiCount++)).append("\n");
            apis.append("      GET /api/v1/orders\n\n");
            apis.append(String.format("   %d. 查询订单详情", apiCount++)).append("\n");
            apis.append("      GET /api/v1/orders/{id}\n\n");
            apis.append(String.format("   %d. 取消订单", apiCount++)).append("\n");
            apis.append("      PUT /api/v1/orders/{id}/cancel\n\n");
            apis.append(String.format("   %d. 支付订单", apiCount++)).append("\n");
            apis.append("      POST /api/v1/payments/create\n\n");
            apis.append(String.format("   %d. 支付回调", apiCount++)).append("\n");
            apis.append("      POST /api/v1/payments/callback\n\n");
        }
        
        if (keywords.contains("file")) {
            apis.append("◆ 文件相关接口\n");
            apis.append(String.format("   %d. 文件上传", apiCount++)).append("\n");
            apis.append("      POST /api/v1/files/upload\n");
            apis.append("      Content-Type: multipart/form-data\n\n");
            apis.append(String.format("   %d. 文件下载", apiCount++)).append("\n");
            apis.append("      GET /api/v1/files/{id}\n\n");
            apis.append(String.format("   %d. 文件删除", apiCount++)).append("\n");
            apis.append("      DELETE /api/v1/files/{id}\n\n");
        }
        
        apis.append("◆ 通用接口规范\n");
        apis.append("   - 统一响应格式: {code, message, data}\n");
        apis.append("   - 分页参数: page, size, sort\n");
        apis.append("   - 认证方式: JWT Token (Authorization Header)\n");
        
        return apis.toString();
    }

    private String generateSecurity(String requirement, List<String> keywords) {
        StringBuilder security = new StringBuilder();
        
        security.append("【身份认证】\n");
        security.append("  - 采用 JWT + Spring Security 认证机制\n");
        security.append("  - Token有效期：2小时，支持刷新Token\n");
        security.append("  - 密码使用 BCrypt 加密存储\n");
        security.append("  - 登录失败锁定策略（连续5次失败锁定30分钟）\n\n");
        
        security.append("【接口安全】\n");
        security.append("  - 所有接口（除登录注册外）需要Token认证\n");
        security.append("  - 接口幂等性设计（防止重复提交）\n");
        security.append("  - 请求参数使用 @Validated 校验\n");
        security.append("  - 全局XSS过滤和SQL注入防护\n");
        security.append("  - 接口限流防止恶意攻击\n\n");
        
        security.append("【数据安全】\n");
        security.append("  - 敏感数据（密码、身份证、银行卡）脱敏显示\n");
        security.append("  - 重要操作日志记录（审计）\n");
        security.append("  - 数据库连接信息配置在环境变量\n");
        security.append("  - 定期备份数据\n\n");
        
        if (keywords.contains("payment")) {
            security.append("【支付安全】\n");
            security.append("  - 支付参数签名验证\n");
            security.append("  - 支付金额前后端双重校验\n");
            security.append("  - 订单状态乐观锁控制\n");
            security.append("  - 支付回调接口验签\n");
        }
        
        return security.toString();
    }

    private String generatePerformance(String requirement, List<String> keywords) {
        StringBuilder perf = new StringBuilder();
        
        perf.append("【数据库优化】\n");
        perf.append("  - 为频繁查询的字段建立索引\n");
        perf.append("  - 大表数据水平拆分（按时间/区域）\n");
        perf.append("  - 读写分离，主从复制\n");
        perf.append("  - SQL优化，避免全表扫描\n\n");
        
        perf.append("【缓存策略】\n");
        perf.append("  - 使用Redis缓存热点数据\n");
        perf.append("  - 设置合理的缓存过期时间\n");
        perf.append("  - 防止缓存击穿、缓存雪崩、缓存穿透\n");
        perf.append("  - 采用缓存双写一致性策略\n\n");
        
        perf.append("【接口优化】\n");
        perf.append("  - 异步处理耗时操作（使用@Async或消息队列）\n");
        perf.append("  - 批量操作减少数据库交互\n");
        perf.append("  - 接口数据按需返回（DTO模式）\n");
        perf.append("  - 大文件分块上传下载\n\n");
        
        perf.append("【架构优化】\n");
        perf.append("  - 服务拆分，微服务架构\n");
        perf.append("  - 引入消息队列解耦\n");
        perf.append("  - 使用CDN加速静态资源\n");
        perf.append("  - 引入分布式搜索引擎\n\n");
        
        perf.append("【监控告警】\n");
        perf.append("  - 集成Prometheus + Grafana监控\n");
        perf.append("  - 配置慢SQL告警\n");
        perf.append("  - 接口响应超时告警\n");
        perf.append("  - 服务器资源（CPU/内存/磁盘）监控\n");
        
        return perf.toString();
    }
}
