package com.solution.generator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PrototypeGenerator {

    public static class PagePrototype {
        private String pageName;
        private String description;
        private List<ComponentInfo> components;
        private String layoutType;

        public PagePrototype(String pageName, String description) {
            this.pageName = pageName;
            this.description = description;
            this.components = new ArrayList<>();
            this.layoutType = "border";
        }

        public String getPageName() { return pageName; }
        public String getDescription() { return description; }
        public List<ComponentInfo> getComponents() { return components; }
        public String getLayoutType() { return layoutType; }
        public void setLayoutType(String layoutType) { this.layoutType = layoutType; }
        public void addComponent(ComponentInfo component) { this.components.add(component); }
    }

    public static class ComponentInfo {
        private String type;
        private String label;
        private String position;
        private int width;
        private int height;
        private boolean isRequired;
        private String inputType;
        private List<String> options;

        public ComponentInfo(String type, String label) {
            this.type = type;
            this.label = label;
            this.position = "center";
            this.width = 200;
            this.height = 35;
            this.isRequired = false;
            this.inputType = "text";
            this.options = new ArrayList<>();
        }

        public String getType() { return type; }
        public String getLabel() { return label; }
        public String getPosition() { return position; }
        public int getWidth() { return width; }
        public int getHeight() { return height; }
        public boolean isRequired() { return isRequired; }
        public String getInputType() { return inputType; }
        public List<String> getOptions() { return options; }

        public ComponentInfo position(String position) { this.position = position; return this; }
        public ComponentInfo size(int width, int height) { this.width = width; this.height = height; return this; }
        public ComponentInfo required() { this.isRequired = true; return this; }
        public ComponentInfo inputType(String inputType) { this.inputType = inputType; return this; }
        public ComponentInfo addOption(String option) { this.options.add(option); return this; }
    }

    public List<PagePrototype> generatePrototypes(String requirement) {
        List<PagePrototype> pages = new ArrayList<>();
        List<String> keywords = extractKeywords(requirement.toLowerCase());
        Map<String, Boolean> features = analyzeFeatures(requirement, keywords);

        if (features.getOrDefault("login", false)) {
            pages.add(createLoginPage());
        }
        if (features.getOrDefault("register", false)) {
            pages.add(createRegisterPage());
        }
        if (features.getOrDefault("dashboard", false)) {
            pages.add(createDashboardPage());
        }
        if (features.getOrDefault("userManagement", false)) {
            pages.add(createUserManagementPage());
        }
        if (features.getOrDefault("orderManagement", false)) {
            pages.add(createOrderManagementPage());
        }
        if (features.getOrDefault("productManagement", false)) {
            pages.add(createProductManagementPage());
        }
        if (features.getOrDefault("setting", false)) {
            pages.add(createSettingsPage());
        }
        if (features.getOrDefault("report", false)) {
            pages.add(createReportPage());
        }

        if (pages.isEmpty()) {
            pages.add(createGenericPage(requirement));
        }

        return pages;
    }

    private List<String> extractKeywords(String requirement) {
        List<String> keywords = new ArrayList<>();
        String[] words = requirement.split("[\\s,，。；;！!？?]+");
        for (String word : words) {
            if (word.length() >= 2) {
                keywords.add(word);
            }
        }
        return keywords;
    }

    private Map<String, Boolean> analyzeFeatures(String requirement, List<String> keywords) {
        Map<String, Boolean> features = new HashMap<>();

        String req = requirement.toLowerCase();

        features.put("login", req.contains("登录") || req.contains("login") || req.contains("signin"));
        features.put("register", req.contains("注册") || req.contains("register") || req.contains("signup"));
        features.put("dashboard", req.contains("仪表盘") || req.contains("dashboard") || req.contains("首页") || req.contains("主页"));
        features.put("userManagement", req.contains("用户管理") || req.contains("用户列表") || req.contains("管理员"));
        features.put("orderManagement", req.contains("订单") || req.contains("order") || req.contains("支付"));
        features.put("productManagement", req.contains("商品") || req.contains("产品") || req.contains("product"));
        features.put("setting", req.contains("设置") || req.contains("setting") || req.contains("配置"));
        features.put("report", req.contains("报表") || req.contains("统计") || req.contains("report") || req.contains("分析"));

        if (req.contains("管理系统") || req.contains("后台系统")) {
            features.put("login", true);
            features.put("dashboard", true);
            features.put("userManagement", true);
            features.put("setting", true);
        }

        if (req.contains("电商") || req.contains("商城") || req.contains("购物")) {
            features.put("login", true);
            features.put("register", true);
            features.put("productManagement", true);
            features.put("orderManagement", true);
        }

        return features;
    }

    private PagePrototype createLoginPage() {
        PagePrototype page = new PagePrototype("用户登录", "系统登录界面，用户输入用户名和密码进行身份验证");
        page.setLayoutType("grid");

        page.addComponent(new ComponentInfo("label", "欢迎登录系统")
                .position("north")
                .size(300, 40));

        page.addComponent(new ComponentInfo("text", "用户名/手机号")
                .position("center")
                .size(280, 40)
                .required());

        page.addComponent(new ComponentInfo("password", "密码")
                .position("center")
                .size(280, 40)
                .required());

        page.addComponent(new ComponentInfo("checkbox", "记住我")
                .position("center")
                .size(100, 30));

        page.addComponent(new ComponentInfo("button", "登录")
                .position("center")
                .size(280, 45));

        page.addComponent(new ComponentInfo("link", "忘记密码？")
                .position("center")
                .size(100, 30));

        page.addComponent(new ComponentInfo("link", "没有账号？立即注册")
                .position("south")
                .size(150, 30));

        return page;
    }

    private PagePrototype createRegisterPage() {
        PagePrototype page = new PagePrototype("用户注册", "新用户注册界面，填写基本信息完成账号注册");
        page.setLayoutType("grid");

        page.addComponent(new ComponentInfo("label", "用户注册")
                .position("north")
                .size(300, 40));

        page.addComponent(new ComponentInfo("text", "用户名")
                .position("center")
                .size(280, 40)
                .required());

        page.addComponent(new ComponentInfo("text", "手机号")
                .position("center")
                .size(280, 40)
                .required()
                .inputType("phone"));

        page.addComponent(new ComponentInfo("text", "验证码")
                .position("center")
                .size(180, 40)
                .required());

        page.addComponent(new ComponentInfo("button", "获取验证码")
                .position("center")
                .size(100, 40));

        page.addComponent(new ComponentInfo("password", "设置密码")
                .position("center")
                .size(280, 40)
                .required());

        page.addComponent(new ComponentInfo("password", "确认密码")
                .position("center")
                .size(280, 40)
                .required());

        page.addComponent(new ComponentInfo("checkbox", "我已阅读并同意用户协议")
                .position("center")
                .size(200, 30)
                .required());

        page.addComponent(new ComponentInfo("button", "立即注册")
                .position("center")
                .size(280, 45));

        page.addComponent(new ComponentInfo("link", "已有账号？立即登录")
                .position("south")
                .size(150, 30));

        return page;
    }

    private PagePrototype createDashboardPage() {
        PagePrototype page = new PagePrototype("数据仪表盘", "系统首页，展示关键数据指标和统计图表");
        page.setLayoutType("border");

        page.addComponent(new ComponentInfo("label", "欢迎回来，管理员")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("card", "今日访问量")
                .position("north")
                .size(200, 100));

        page.addComponent(new ComponentInfo("card", "新增用户")
                .position("north")
                .size(200, 100));

        page.addComponent(new ComponentInfo("card", "订单数量")
                .position("north")
                .size(200, 100));

        page.addComponent(new ComponentInfo("card", "销售额")
                .position("north")
                .size(200, 100));

        page.addComponent(new ComponentInfo("chart", "销售趋势图")
                .position("center")
                .size(500, 300));

        page.addComponent(new ComponentInfo("table", "最近订单")
                .position("south")
                .size(500, 200));

        return page;
    }

    private PagePrototype createUserManagementPage() {
        PagePrototype page = new PagePrototype("用户管理", "用户信息管理界面，支持增删改查操作");
        page.setLayoutType("border");

        page.addComponent(new ComponentInfo("label", "用户管理")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("text", "搜索用户（用户名/手机号）")
                .position("north")
                .size(300, 35));

        page.addComponent(new ComponentInfo("button", "搜索")
                .position("north")
                .size(80, 35));

        page.addComponent(new ComponentInfo("button", "新增用户")
                .position("north")
                .size(100, 35));

        page.addComponent(new ComponentInfo("select", "用户状态")
                .position("north")
                .size(120, 35)
                .addOption("全部")
                .addOption("正常")
                .addOption("禁用"));

        page.addComponent(new ComponentInfo("table", "用户列表")
                .position("center")
                .size(800, 400));

        page.addComponent(new ComponentInfo("button", "编辑")
                .position("center")
                .size(70, 30));

        page.addComponent(new ComponentInfo("button", "删除")
                .position("center")
                .size(70, 30));

        page.addComponent(new ComponentInfo("pagination", "分页")
                .position("south")
                .size(400, 30));

        return page;
    }

    private PagePrototype createOrderManagementPage() {
        PagePrototype page = new PagePrototype("订单管理", "订单信息管理界面，查看和处理订单");
        page.setLayoutType("border");

        page.addComponent(new ComponentInfo("label", "订单管理")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("text", "订单号/商品名称")
                .position("north")
                .size(250, 35));

        page.addComponent(new ComponentInfo("select", "订单状态")
                .position("north")
                .size(120, 35)
                .addOption("全部状态")
                .addOption("待付款")
                .addOption("待发货")
                .addOption("已发货")
                .addOption("已完成")
                .addOption("已取消"));

        page.addComponent(new ComponentInfo("button", "查询")
                .position("north")
                .size(80, 35));

        page.addComponent(new ComponentInfo("button", "导出")
                .position("north")
                .size(80, 35));

        page.addComponent(new ComponentInfo("table", "订单列表")
                .position("center")
                .size(800, 400));

        page.addComponent(new ComponentInfo("button", "查看详情")
                .position("center")
                .size(90, 30));

        page.addComponent(new ComponentInfo("button", "发货")
                .position("center")
                .size(70, 30));

        page.addComponent(new ComponentInfo("pagination", "分页")
                .position("south")
                .size(400, 30));

        return page;
    }

    private PagePrototype createProductManagementPage() {
        PagePrototype page = new PagePrototype("商品管理", "商品信息管理界面，管理商品上架和库存");
        page.setLayoutType("border");

        page.addComponent(new ComponentInfo("label", "商品管理")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("text", "商品名称/编码")
                .position("north")
                .size(250, 35));

        page.addComponent(new ComponentInfo("select", "商品分类")
                .position("north")
                .size(120, 35)
                .addOption("全部分类")
                .addOption("电子产品")
                .addOption("服装服饰")
                .addOption("食品饮料")
                .addOption("家居用品"));

        page.addComponent(new ComponentInfo("select", "上架状态")
                .position("north")
                .size(100, 35)
                .addOption("全部")
                .addOption("已上架")
                .addOption("已下架"));

        page.addComponent(new ComponentInfo("button", "搜索")
                .position("north")
                .size(80, 35));

        page.addComponent(new ComponentInfo("button", "新增商品")
                .position("north")
                .size(100, 35));

        page.addComponent(new ComponentInfo("table", "商品列表")
                .position("center")
                .size(800, 400));

        page.addComponent(new ComponentInfo("button", "编辑")
                .position("center")
                .size(70, 30));

        page.addComponent(new ComponentInfo("button", "上架/下架")
                .position("center")
                .size(90, 30));

        page.addComponent(new ComponentInfo("pagination", "分页")
                .position("south")
                .size(400, 30));

        return page;
    }

    private PagePrototype createSettingsPage() {
        PagePrototype page = new PagePrototype("系统设置", "系统配置界面，设置系统参数和个人信息");
        page.setLayoutType("grid");

        page.addComponent(new ComponentInfo("label", "系统设置")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("label", "个人信息")
                .position("center")
                .size(300, 25));

        page.addComponent(new ComponentInfo("text", "昵称")
                .position("center")
                .size(280, 40));

        page.addComponent(new ComponentInfo("text", "邮箱")
                .position("center")
                .size(280, 40)
                .inputType("email"));

        page.addComponent(new ComponentInfo("text", "手机号")
                .position("center")
                .size(280, 40)
                .inputType("phone"));

        page.addComponent(new ComponentInfo("label", "安全设置")
                .position("center")
                .size(300, 25));

        page.addComponent(new ComponentInfo("password", "原密码")
                .position("center")
                .size(280, 40));

        page.addComponent(new ComponentInfo("password", "新密码")
                .position("center")
                .size(280, 40));

        page.addComponent(new ComponentInfo("password", "确认新密码")
                .position("center")
                .size(280, 40));

        page.addComponent(new ComponentInfo("label", "系统配置")
                .position("center")
                .size(300, 25));

        page.addComponent(new ComponentInfo("select", "主题颜色")
                .position("center")
                .size(280, 40)
                .addOption("浅色主题")
                .addOption("深色主题")
                .addOption("蓝色主题"));

        page.addComponent(new ComponentInfo("select", "语言")
                .position("center")
                .size(280, 40)
                .addOption("简体中文")
                .addOption("English"));

        page.addComponent(new ComponentInfo("button", "保存设置")
                .position("south")
                .size(280, 45));

        return page;
    }

    private PagePrototype createReportPage() {
        PagePrototype page = new PagePrototype("数据报表", "数据统计报表界面，展示各类统计图表");
        page.setLayoutType("border");

        page.addComponent(new ComponentInfo("label", "数据报表")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("select", "报表类型")
                .position("north")
                .size(150, 35)
                .addOption("销售报表")
                .addOption("用户报表")
                .addOption("流量报表")
                .addOption("商品报表"));

        page.addComponent(new ComponentInfo("select", "时间范围")
                .position("north")
                .size(120, 35)
                .addOption("今日")
                .addOption("本周")
                .addOption("本月")
                .addOption("今年")
                .addOption("自定义"));

        page.addComponent(new ComponentInfo("text", "开始日期")
                .position("north")
                .size(120, 35)
                .inputType("date"));

        page.addComponent(new ComponentInfo("text", "结束日期")
                .position("north")
                .size(120, 35)
                .inputType("date"));

        page.addComponent(new ComponentInfo("button", "查询")
                .position("north")
                .size(80, 35));

        page.addComponent(new ComponentInfo("button", "导出Excel")
                .position("north")
                .size(100, 35));

        page.addComponent(new ComponentInfo("chart", "趋势图")
                .position("center")
                .size(600, 300));

        page.addComponent(new ComponentInfo("chart", "饼图")
                .position("center")
                .size(300, 300));

        page.addComponent(new ComponentInfo("table", "数据明细")
                .position("south")
                .size(800, 200));

        return page;
    }

    private PagePrototype createGenericPage(String requirement) {
        PagePrototype page = new PagePrototype("通用界面", "根据需求生成的通用界面原型");
        page.setLayoutType("grid");

        page.addComponent(new ComponentInfo("label", "系统界面")
                .position("north")
                .size(400, 30));

        page.addComponent(new ComponentInfo("text", "输入框1")
                .position("center")
                .size(280, 40));

        page.addComponent(new ComponentInfo("text", "输入框2")
                .position("center")
                .size(280, 40));

        page.addComponent(new ComponentInfo("select", "下拉选择")
                .position("center")
                .size(280, 40)
                .addOption("选项1")
                .addOption("选项2")
                .addOption("选项3"));

        page.addComponent(new ComponentInfo("textarea", "多行文本")
                .position("center")
                .size(280, 100));

        page.addComponent(new ComponentInfo("checkbox", "选项A")
                .position("center")
                .size(100, 30));

        page.addComponent(new ComponentInfo("checkbox", "选项B")
                .position("center")
                .size(100, 30));

        page.addComponent(new ComponentInfo("radio", "单选A")
                .position("center")
                .size(100, 30));

        page.addComponent(new ComponentInfo("radio", "单选B")
                .position("center")
                .size(100, 30));

        page.addComponent(new ComponentInfo("button", "确认")
                .position("south")
                .size(120, 45));

        page.addComponent(new ComponentInfo("button", "取消")
                .position("south")
                .size(120, 45));

        return page;
    }

    public String generatePrototypeDescription(List<PagePrototype> pages) {
        StringBuilder desc = new StringBuilder();
        desc.append("========================================\n");
        desc.append("           原型图设计方案\n");
        desc.append("========================================\n\n");

        desc.append("【页面导航结构】\n");
        desc.append("┌─────────────────────────────────────┐\n");
        desc.append("│           顶部导航栏                  │\n");
        desc.append("│ Logo | 首页 | 功能菜单 | 用户信息   │\n");
        desc.append("├──────────┬──────────────────────────┤\n");
        desc.append("│          │                          │\n");
        desc.append("│  左侧菜单 │      主内容区域          │\n");
        desc.append("│          │                          │\n");
        desc.append("│ - 首页   │                          │\n");
        desc.append("│ - 用户   │                          │\n");
        desc.append("│ - 订单   │                          │\n");
        desc.append("│ - 商品   │                          │\n");
        desc.append("│ - 报表   │                          │\n");
        desc.append("│ - 设置   │                          │\n");
        desc.append("│          │                          │\n");
        desc.append("└──────────┴──────────────────────────┘\n\n");

        desc.append("========================================\n\n");
        desc.append("【页面详情】\n\n");

        for (int i = 0; i < pages.size(); i++) {
            PagePrototype page = pages.get(i);
            desc.append(String.format("┌─────────────────────────────────────┐\n"));
            desc.append(String.format("│  页面 %d: %s\n", i + 1, page.getPageName()));
            desc.append(String.format("├─────────────────────────────────────┤\n"));
            desc.append(String.format("│  功能说明: %s\n", page.getDescription()));
            desc.append(String.format("│  布局方式: %s布局\n", page.getLayoutType().equals("grid") ? "表单网格" : "区域边界"));
            desc.append(String.format("├─────────────────────────────────────┤\n"));
            desc.append("│  包含组件:\n");

            for (ComponentInfo comp : page.getComponents()) {
                String compType = getComponentTypeName(comp.getType());
                String required = comp.isRequired() ? " *必填" : "";
                desc.append(String.format("│    ├── [%s] %s%s\n", compType, comp.getLabel(), required));
            }
            desc.append(String.format("└─────────────────────────────────────┘\n\n"));
        }

        desc.append("========================================\n");
        desc.append("           原型图已生成完毕\n");
        desc.append("========================================\n");
        desc.append("\n提示：点击左侧页面导航可预览各页面的原型效果");

        return desc.toString();
    }

    private String getComponentTypeName(String type) {
        Map<String, String> typeNames = new HashMap<>();
        typeNames.put("label", "标签");
        typeNames.put("text", "文本框");
        typeNames.put("password", "密码框");
        typeNames.put("textarea", "多行文本");
        typeNames.put("button", "按钮");
        typeNames.put("checkbox", "复选框");
        typeNames.put("radio", "单选框");
        typeNames.put("select", "下拉选择");
        typeNames.put("link", "链接");
        typeNames.put("card", "卡片");
        typeNames.put("chart", "图表");
        typeNames.put("table", "数据表格");
        typeNames.put("pagination", "分页");
        typeNames.put("image", "图片");

        return typeNames.getOrDefault(type, type);
    }
}
