package com.solution.generator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SolutionGeneratorGUI extends JFrame {

    private JTextArea requirementArea;
    private JTextArea solutionArea;
    private SolutionGenerator generator;
    private PrototypeGenerator prototypeGenerator;

    public SolutionGeneratorGUI() {
        generator = new SolutionGenerator();
        prototypeGenerator = new PrototypeGenerator();
        initUI();
    }

    private void initUI() {
        setTitle("软件需求解决方案生成器");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel topPanel = createTopPanel();
        mainPanel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = createCenterPanel();
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = createBottomPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createTopPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(0, 0, 10, 0));

        JLabel titleLabel = new JLabel("软件需求解决方案生成器", JLabel.CENTER);
        titleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
        titleLabel.setForeground(new Color(51, 122, 183));
        panel.add(titleLabel, BorderLayout.NORTH);

        JLabel descLabel = new JLabel("输入您的软件需求描述，点击按钮获取详细的技术解决方案", JLabel.CENTER);
        descLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        descLabel.setForeground(Color.GRAY);
        descLabel.setBorder(new EmptyBorder(10, 0, 0, 0));
        panel.add(descLabel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createCenterPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));

        JPanel leftPanel = createInputPanel();
        JPanel rightPanel = createOutputPanel();

        panel.add(leftPanel);
        panel.add(rightPanel);

        return panel;
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));

        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " 输入软件需求 ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Microsoft YaHei", Font.BOLD, 14),
                new Color(51, 122, 183)
        );
        panel.setBorder(border);

        requirementArea = new JTextArea();
        requirementArea.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        requirementArea.setLineWrap(true);
        requirementArea.setWrapStyleWord(true);
        requirementArea.setMargin(new Insets(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(requirementArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        JPanel hintPanel = new JPanel(new BorderLayout());
        JLabel hintLabel = new JLabel("  示例：我需要一个用户管理系统，包含用户注册、登录、权限管理功能");
        hintLabel.setFont(new Font("Microsoft YaHei", Font.ITALIC, 12));
        hintLabel.setForeground(Color.GRAY);
        hintPanel.add(hintLabel, BorderLayout.WEST);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(hintPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createOutputPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));

        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                " 解决方案输出 ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Microsoft YaHei", Font.BOLD, 14),
                new Color(51, 122, 183)
        );
        panel.setBorder(border);

        solutionArea = new JTextArea();
        solutionArea.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        solutionArea.setLineWrap(true);
        solutionArea.setWrapStyleWord(true);
        solutionArea.setEditable(false);
        solutionArea.setMargin(new Insets(10, 10, 10, 10));
        solutionArea.setBackground(new Color(248, 248, 248));

        JScrollPane scrollPane = new JScrollPane(solutionArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createBottomPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton generateBtn = new JButton("生成解决方案");
        generateBtn.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        generateBtn.setPreferredSize(new Dimension(200, 45));
        generateBtn.setBackground(new Color(66, 139, 202));
        generateBtn.setForeground(Color.WHITE);
        generateBtn.setFocusPainted(false);
        generateBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        generateBtn.setOpaque(true);
        generateBtn.setBorderPainted(false);
        generateBtn.setContentAreaFilled(true);
        generateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateSolution();
            }
        });

        JButton prototypeBtn = new JButton("生成原型图");
        prototypeBtn.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        prototypeBtn.setPreferredSize(new Dimension(200, 45));
        prototypeBtn.setBackground(new Color(155, 89, 182));
        prototypeBtn.setForeground(Color.WHITE);
        prototypeBtn.setFocusPainted(false);
        prototypeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        prototypeBtn.setOpaque(true);
        prototypeBtn.setBorderPainted(false);
        prototypeBtn.setContentAreaFilled(true);
        prototypeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePrototype();
            }
        });

        JButton clearBtn = new JButton("清空内容");
        clearBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        clearBtn.setPreferredSize(new Dimension(120, 45));
        clearBtn.setBackground(new Color(243, 156, 18));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);
        clearBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        clearBtn.setOpaque(true);
        clearBtn.setBorderPainted(false);
        clearBtn.setContentAreaFilled(true);
        clearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearAll();
            }
        });

        JButton copyBtn = new JButton("复制结果");
        copyBtn.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        copyBtn.setPreferredSize(new Dimension(120, 45));
        copyBtn.setBackground(new Color(39, 174, 96));
        copyBtn.setForeground(Color.WHITE);
        copyBtn.setFocusPainted(false);
        copyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        copyBtn.setOpaque(true);
        copyBtn.setBorderPainted(false);
        copyBtn.setContentAreaFilled(true);
        copyBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                copySolution();
            }
        });

        panel.add(generateBtn);
        panel.add(prototypeBtn);
        panel.add(clearBtn);
        panel.add(copyBtn);

        return panel;
    }

    private void generatePrototype() {
        String requirement = requirementArea.getText().trim();

        if (requirement.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "请先输入软件需求内容！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        solutionArea.setText("正在生成原型图，请稍候...\n");
        solutionArea.paintImmediately(solutionArea.getBounds());

        SwingWorker<List<PrototypeGenerator.PagePrototype>, Void> worker = new SwingWorker<List<PrototypeGenerator.PagePrototype>, Void>() {
            @Override
            protected List<PrototypeGenerator.PagePrototype> doInBackground() throws Exception {
                Thread.sleep(500);
                return prototypeGenerator.generatePrototypes(requirement);
            }

            @Override
            protected void done() {
                try {
                    List<PrototypeGenerator.PagePrototype> pages = get();
                    String description = prototypeGenerator.generatePrototypeDescription(pages);
                    solutionArea.setText(description);
                    solutionArea.setCaretPosition(0);

                    PrototypePreviewFrame previewFrame = new PrototypePreviewFrame(pages);
                    previewFrame.setVisible(true);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(SolutionGeneratorGUI.this,
                            "生成原型图时发生错误：" + ex.getMessage(),
                            "错误",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        };

        worker.execute();
    }

    private void generateSolution() {
        String requirement = requirementArea.getText().trim();

        if (requirement.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "请先输入软件需求内容！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        solutionArea.setText("正在生成解决方案，请稍候...\n");
        solutionArea.paintImmediately(solutionArea.getBounds());

        SwingWorker<String, Void> worker = new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                Thread.sleep(500);
                return generator.generateSolution(requirement);
            }

            @Override
            protected void done() {
                try {
                    String solution = get();
                    solutionArea.setText(solution);
                    solutionArea.setCaretPosition(0);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(SolutionGeneratorGUI.this,
                            "生成解决方案时发生错误：" + ex.getMessage(),
                            "错误",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        };

        worker.execute();
    }

    private void clearAll() {
        int result = JOptionPane.showConfirmDialog(this,
                "确定要清空所有内容吗？",
                "确认",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (result == JOptionPane.YES_OPTION) {
            requirementArea.setText("");
            solutionArea.setText("");
        }
    }

    private void copySolution() {
        String solution = solutionArea.getText().trim();
        if (solution.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "没有可复制的内容！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        solutionArea.selectAll();
        solutionArea.copy();

        JOptionPane.showMessageDialog(this,
                "解决方案已复制到剪贴板！",
                "成功",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
